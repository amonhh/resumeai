const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Upload, FileText, Loader2, CheckCircle2 } from "lucide-react";

import mammoth from "mammoth";
import { toast } from "sonner";

export default function UploadResumeDialog({ open, onClose, onResumeExtracted }) {
  const [uploading, setUploading] = useState(false);
  const [extracting, setExtracting] = useState(false);
  const [file, setFile] = useState(null);
  const [error, setError] = useState(null);
  const [status, setStatus] = useState('');

  const handleFileChange = (e) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      const validTypes = [
        'application/pdf',
        'image/png', 'image/jpeg', 'image/jpg',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/msword'
      ];
      const validExtensions = ['.pdf', '.png', '.jpg', '.jpeg', '.docx', '.doc'];
      const ext = '.' + selectedFile.name.split('.').pop().toLowerCase();
      if (validTypes.includes(selectedFile.type) || validExtensions.includes(ext)) {
        setFile(selectedFile);
      } else {
        toast.error('Please upload a PDF, DOCX, PNG, or JPG file');
      }
    }
  };

  const handleUploadAndExtract = async () => {
    if (!file) {
      toast.error('Please select a file');
      return;
    }

    setUploading(true);
    setExtracting(true);
    setError(null);
    setStatus('Uploading file...');

    try {
      const isDocx = file.name.toLowerCase().endsWith('.docx') || file.name.toLowerCase().endsWith('.doc');

      const responseSchema = {
        type: "object",
        properties: {
          personal_details: {
            type: "object",
            properties: {
              full_name: { type: "string" },
              job_title: { type: "string" },
              email: { type: "string" },
              phone: { type: "string" },
              location: { type: "string" },
              linkedin: { type: "string" },
              website: { type: "string" }
            }
          },
          summary: { type: "string" },
          experience: {
            type: "array",
            items: {
              type: "object",
              properties: {
                job_title: { type: "string" },
                company: { type: "string" },
                location: { type: "string" },
                start_date: { type: "string" },
                end_date: { type: "string" },
                current: { type: "boolean" },
                description: { type: "string" },
                achievements: { type: "array", items: { type: "string" } }
              }
            }
          },
          education: {
            type: "array",
            items: {
              type: "object",
              properties: {
                degree: { type: "string" },
                institution: { type: "string" },
                location: { type: "string" },
                start_date: { type: "string" },
                end_date: { type: "string" },
                gpa: { type: "string" }
              }
            }
          },
          skills: {
            type: "array",
            items: {
              type: "object",
              properties: { name: { type: "string" }, level: { type: "string" } }
            }
          }
        }
      };

      let extractedData = null;

      if (isDocx) {
        // Extract text from DOCX using mammoth locally
        setStatus('Reading document...');
        const arrayBuffer = await file.arrayBuffer();
        const { value: docText } = await mammoth.extractRawText({ arrayBuffer });
        if (!docText || docText.trim().length === 0) {
          throw new Error('Could not read text from the DOCX file.');
        }
        setStatus('Extracting resume data...');
        extractedData = await db.integrations.Core.InvokeLLM({
          prompt: `Extract all resume/CV information from the following document text. Parse every section carefully including personal details, work experience, education, and skills. Return structured data.\n\n---\n${docText}`,
          response_json_schema: responseSchema
        });
      } else {
        // Use ExtractDataFromUploadedFile for PDF/images
        setStatus('Extracting resume data...');
        const { file_url } = await db.integrations.Core.UploadFile({ file });
        const result = await db.integrations.Core.ExtractDataFromUploadedFile({
          file_url,
          json_schema: responseSchema
        });
        if (result.status === 'success' && result.output) {
          extractedData = result.output;
        } else {
          throw new Error(result.details || 'Extraction failed');
        }
      }

      if (extractedData) {
        setStatus('');
        onResumeExtracted(extractedData);
        onClose();
      } else {
        setError('Could not extract data from the file. Please try again.');
      }
    } catch (err) {
      console.error('Error uploading/extracting resume:', err);
      setError(err?.message || 'Failed to process the file. Please try again.');
    } finally {
      setUploading(false);
      setExtracting(false);
      setStatus('');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-blue-600" />
            Upload Your Resume
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-500 transition-colors">
            <input
              type="file"
              id="resume-upload"
              className="hidden"
              accept=".pdf,.png,.jpg,.jpeg,.docx,.doc"
              onChange={handleFileChange}
              disabled={uploading}
            />
            <label htmlFor="resume-upload" className="cursor-pointer">
              {file ? (
                <div className="space-y-3">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-8 h-8 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{file.name}</p>
                    <p className="text-sm text-gray-500 mt-1">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                  <Button type="button" variant="outline" size="sm">
                    Choose Different File
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                    <FileText className="w-8 h-8 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Click to upload resume</p>
                    <p className="text-sm text-gray-500 mt-1">
                      PDF, DOCX, PNG, JPG (max 10MB)
                    </p>
                  </div>
                </div>
              )}
            </label>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-4 py-3">
              {error}
            </div>
          )}

          {status && (
            <div className="flex items-center gap-2 text-sm text-blue-600 justify-center">
              <Loader2 className="w-4 h-4 animate-spin" />
              {status}
            </div>
          )}

          {file && (
            <Button 
              onClick={handleUploadAndExtract}
              disabled={uploading || extracting}
              className="w-full bg-blue-600 hover:bg-blue-700"
              size="lg"
            >
              {uploading || extracting ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  {status || 'Processing...'}
                </>
              ) : (
                <>
                  <Upload className="w-5 h-5 mr-2" />
                  Import Resume
                </>
              )}
            </Button>
          )}

          <div className="text-center">
            <p className="text-xs text-gray-500">
              We'll automatically extract your information from the resume
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}