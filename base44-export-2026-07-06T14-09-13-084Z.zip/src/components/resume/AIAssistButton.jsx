const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Sparkles, Loader2, Check, Wand2, Plus, RefreshCw } from "lucide-react";

import { toast } from "sonner";

export default function AIAssistButton({ section, currentContent = '', context = '', onApply }) {
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState(currentContent?.trim() ? 'improve' : 'generate');
  const [options, setOptions] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(false);

  const hasContent = currentContent?.trim().length > 0;

  const handleGenerate = async (selectedMode) => {
    const m = selectedMode || mode;
    setMode(m);
    setLoading(true);
    setOptions([]);
    setSelected(null);
    try {
      const response = await db.integrations.Core.InvokeLLM({
        prompt: `You are an expert resume writer. Section: "${section}".
Existing content: ${currentContent || '(empty)'}
Extra context: ${context || 'N/A'}

Task: ${m === 'improve' ? 'Rewrite the existing content to be more professional, impactful, and achievement-focused. Keep it concise. Preserve key facts.' : m === 'expand' ? 'Expand the existing content with more relevant detail, quantifiable achievements, and professional language. Keep it truthful to the existing content.' : 'Generate professional, impactful content for this section from the context provided. Use bullet points where appropriate.'}

Provide EXACTLY 3 distinct options. Each option must be a different tone/style. Return as a JSON object.`,
        response_json_schema: {
          type: "object",
          properties: {
            options: {
              type: "array",
              items: { type: "string" },
              description: "Three distinct content options"
            }
          }
        }
      });
      setOptions(response.options || []);
    } catch (error) {
      toast.error('AI could not generate options');
    } finally {
      setLoading(false);
    }
  };

  const handleApply = () => {
    if (selected === null) return;
    onApply(options[selected]);
    setOpen(false);
    setOptions([]);
    setSelected(null);
    toast.success('Content applied');
  };

  const reset = () => {
    setOptions([]);
    setSelected(null);
  };

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        onClick={() => setOpen(true)}
        className="gap-1.5 text-blue-600 border-blue-200 hover:bg-blue-50"
      >
        <Sparkles className="w-3.5 h-3.5" />
        AI Assist
      </Button>

      <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) reset(); }}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-blue-600" />
              AI Assist — {section}
            </DialogTitle>
            <DialogDescription>
              {hasContent ? 'Refine, expand, or rewrite your existing content.' : 'Generate professional content from your context.'}
            </DialogDescription>
          </DialogHeader>

          {hasContent && (
            <div className="rounded-lg border bg-gray-50 p-3">
              <p className="text-xs font-medium text-gray-500 mb-1">Current content:</p>
              <p className="text-sm text-gray-700 whitespace-pre-wrap max-h-28 overflow-y-auto">{currentContent}</p>
            </div>
          )}

          {options.length === 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {hasContent && (
                <button
                  onClick={() => handleGenerate('improve')}
                  disabled={loading && mode !== 'improve'}
                  className="flex flex-col items-start gap-2 p-4 rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-colors text-left disabled:opacity-50"
                >
                  <RefreshCw className="w-5 h-5 text-blue-600" />
                  <span className="font-medium text-sm">Improve</span>
                  <span className="text-xs text-gray-500">Rewrite for impact & clarity</span>
                </button>
              )}
              {hasContent && (
                <button
                  onClick={() => handleGenerate('expand')}
                  disabled={loading && mode !== 'expand'}
                  className="flex flex-col items-start gap-2 p-4 rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-colors text-left disabled:opacity-50"
                >
                  <Plus className="w-5 h-5 text-blue-600" />
                  <span className="font-medium text-sm">Expand</span>
                  <span className="text-xs text-gray-500">Add detail & achievements</span>
                </button>
              )}
              <button
                onClick={() => handleGenerate('generate')}
                disabled={loading && mode !== 'generate'}
                className="flex flex-col items-start gap-2 p-4 rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-colors text-left disabled:opacity-50"
              >
                <Wand2 className="w-5 h-5 text-blue-600" />
                <span className="font-medium text-sm">Generate</span>
                <span className="text-xs text-gray-500">Create fresh from context</span>
              </button>
            </div>
          ) : (
            <div className="space-y-3 max-h-[55vh] overflow-y-auto">
              {options.map((opt, i) => (
                <button
                  key={i}
                  onClick={() => setSelected(i)}
                  className={`w-full text-left p-4 rounded-lg border transition-all ${
                    selected === i ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500' : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Option {i + 1}</span>
                    {selected === i && <Check className="w-4 h-4 text-blue-600" />}
                  </div>
                  <p className="text-sm text-gray-800 whitespace-pre-wrap">{opt}</p>
                </button>
              ))}
            </div>
          )}

          {loading && (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
              <span className="ml-2 text-sm text-gray-600">Generating options...</span>
            </div>
          )}

          {options.length > 0 && (
            <div className="flex justify-between items-center pt-2">
              <Button variant="ghost" size="sm" onClick={reset}>
                Back to actions
              </Button>
              <Button onClick={handleApply} disabled={selected === null} className="bg-blue-600 hover:bg-blue-700">
                <Check className="w-4 h-4 mr-1.5" />
                Apply selected option
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}