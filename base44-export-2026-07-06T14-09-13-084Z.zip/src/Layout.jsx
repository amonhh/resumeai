const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { FileText, LayoutTemplate, LogOut } from "lucide-react";

export default function Layout({ children, currentPageName }) {
  const handleLogout = () => {
    db.auth.logout();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between h-16">
            <Link to={createPageUrl('Home')} className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">Stylus CV</span>
            </Link>

            <div className="flex items-center gap-6">
              {!['Home'].includes(currentPageName) && (
                <>
                  <Link 
                    to={createPageUrl('Templates')}
                    className={`text-sm font-medium transition-colors ${
                      currentPageName === 'Templates' 
                        ? 'text-blue-600' 
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    <LayoutTemplate className="w-4 h-4 inline mr-1" />
                    Templates
                  </Link>
                  <Link 
                    to={createPageUrl('Dashboard')}
                    className={`text-sm font-medium transition-colors ${
                      currentPageName === 'Dashboard' 
                        ? 'text-blue-600' 
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    <FileText className="w-4 h-4 inline mr-1" />
                    My Resumes
                  </Link>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={handleLogout}
                    className="text-gray-600"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </Button>
                </>
              )}
              {currentPageName === 'Home' && (
                <>
                  <Link 
                    to={createPageUrl('Templates')}
                    className="text-sm font-medium text-gray-600 hover:text-gray-900"
                  >
                    Templates
                  </Link>
                  <Button 
                    onClick={() => window.location.href = createPageUrl('Dashboard')}
                    size="sm"
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Get Started
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main>{children}</main>

      {/* Footer */}
      <footer className="bg-white border-t mt-20">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="text-center text-gray-600 text-sm">
            <p>© 2024 Stylus CV - AI-Powered Resume Builder</p>
            <p className="mt-2">Create professional resumes with AI assistance</p>
          </div>
        </div>
      </footer>
    </div>
  );
}