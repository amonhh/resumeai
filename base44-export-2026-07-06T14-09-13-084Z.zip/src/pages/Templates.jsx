const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Sparkles, Check } from "lucide-react";
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

import LiveTemplatePreview from '../components/templates/LiveTemplatePreview';
import { toast } from 'sonner';

const TEMPLATES = [
  { id: 'modern-blue', name: 'Modern Blue', category: 'modern', description: 'Blue header with photo section' },
  { id: 'modern-gradient', name: 'Modern Gradient', category: 'modern', description: 'Gradient header, timeline design', badge: 'New' },
  { id: 'modern', name: 'Classic Modern', category: 'modern', description: 'Contemporary, any industry' },
  { id: 'creative-twotone', name: 'Creative Two-Tone', category: 'creative', description: 'Dark sidebar, vibrant accents', badge: 'New' },
  { id: 'bold-modern', name: 'Bold Modern', category: 'creative', description: 'Diagonal cut header design', badge: 'New' },
  { id: 'executive', name: 'Executive', category: 'professional', description: 'Serif design for senior roles', badge: 'New' },
  { id: 'professional-sidebar', name: 'Professional Sidebar', category: 'professional', description: 'Gray sidebar for skills' },
  { id: 'minimal-chic', name: 'Minimal Chic', category: 'simple', description: 'Clean centered typography', badge: 'New' },
  { id: 'minimal-sidebar', name: 'Minimal Sidebar', category: 'simple', description: 'Centered photo, side details' },
  { id: 'ats', name: 'ATS Optimized', category: 'ats', description: 'Passes applicant tracking systems' }
];

const CATEGORIES = [
  { id: 'all', label: 'All' },
  { id: 'modern', label: 'Modern' },
  { id: 'creative', label: 'Creative' },
  { id: 'professional', label: 'Professional' },
  { id: 'simple', label: 'Simple' },
  { id: 'ats', label: 'ATS' }
];

const ASPECT = 'aspect-[210/297]';

export default function Templates() {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [creating, setCreating] = useState(null);

  const filteredTemplates = selectedCategory === 'all'
    ? TEMPLATES
    : TEMPLATES.filter(t => t.category === selectedCategory);

  const handleUseTemplate = async (templateId) => {
    setCreating(templateId);
    try {
      const newResume = await db.entities.Resume.create({
        title: 'Untitled Resume',
        template: templateId,
        personal_details: {},
        experience: [],
        education: [],
        skills: []
      });
      navigate(createPageUrl(`Editor?id=${newResume.id}`));
    } catch (err) {
      toast.error('Could not create resume. Please try again.');
      setCreating(null);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      {/* Hero */}
      <div className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-14 text-center">
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-300 bg-blue-500/10 border border-blue-500/20 rounded-full px-3 py-1 mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            AI-Powered Templates
          </span>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-3">
            Choose a resume template
          </h1>
          <p className="text-lg text-white/60 max-w-2xl mx-auto">
            Pick a design and start editing instantly. Every template is ATS-friendly and fully customizable.
          </p>
        </div>
      </div>

      {/* Category Filter */}
      <div className="max-w-7xl mx-auto px-6 pt-10">
        <div className="flex flex-wrap justify-center gap-2">
          {CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                selectedCategory === cat.id
                  ? 'bg-white text-gray-900'
                  : 'bg-white/5 text-white/60 hover:bg-white/10 hover:text-white border border-white/10'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Templates Grid */}
      <div className="max-w-7xl mx-auto px-6 py-10 pb-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.map(template => (
            <div
              key={template.id}
              className="group relative rounded-2xl border border-white/10 bg-white/[0.03] overflow-hidden transition-all hover:border-white/20 hover:bg-white/[0.06]"
            >
              {template.badge && (
                <div className="absolute top-3 left-3 z-20 bg-blue-500 text-white text-xs font-semibold px-2.5 py-1 rounded-full">
                  {template.badge}
                </div>
              )}

              {/* Live Preview */}
              <div className={`relative ${ASPECT} bg-white overflow-hidden`}>
                <LiveTemplatePreview templateId={template.id} />
                {/* Hover overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/0 to-black/0 opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center pb-6">
                  <Button
                    size="sm"
                    onClick={() => handleUseTemplate(template.id)}
                    disabled={creating === template.id}
                    className="bg-white text-gray-900 hover:bg-white/90"
                  >
                    {creating === template.id ? (
                      <>Loading...</>
                    ) : (
                      <>
                        <Check className="w-4 h-4 mr-1.5" />
                        Use this template
                      </>
                    )}
                  </Button>
                </div>
              </div>

              {/* Info */}
              <div className="p-4">
                <h3 className="font-semibold text-white text-base">{template.name}</h3>
                <p className="text-sm text-white/50 mt-0.5">{template.description}</p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleUseTemplate(template.id)}
                  disabled={creating === template.id}
                  className="w-full mt-3 border-white/15 bg-transparent text-white hover:bg-white/10 hover:text-white"
                >
                  {creating === template.id ? 'Creating...' : 'Use this template'}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}