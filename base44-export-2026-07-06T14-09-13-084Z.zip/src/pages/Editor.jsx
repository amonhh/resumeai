const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Save,
  Eye,
  Download,
  Plus,
  Trash2,
  ArrowLeft,
  Sparkles,
  TrendingUp,
  Loader2,
  Upload
} from "lucide-react";
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import AIAssistButton from '../components/resume/AIAssistButton';
import AISkillsSuggestButton from '../components/resume/AISkillsSuggestButton';
import ResumePreview from '../components/resume/ResumePreview';
import TemplateSelector from '../components/resume/TemplateSelector';
import ScoreFeedbackDialog from '../components/resume/ScoreFeedbackDialog';
import { toast } from 'sonner';

export default function Editor() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const resumeId = urlParams.get('id');
  
  const [activeTab, setActiveTab] = useState('personal');
  const [showPreview, setShowPreview] = useState(true);
  const [resumeData, setResumeData] = useState(null);
  const [calculatingScore, setCalculatingScore] = useState(false);
  const [showTemplateSelector, setShowTemplateSelector] = useState(false);
  const [showScoreFeedback, setShowScoreFeedback] = useState(false);

  const { data: resume, isLoading } = useQuery({
    queryKey: ['resume', resumeId],
    queryFn: async () => {
      const resumes = await db.entities.Resume.filter({ id: resumeId });
      return resumes[0];
    },
    enabled: !!resumeId
  });

  useEffect(() => {
    if (resume) {
      setResumeData(resume);
    }
  }, [resume]);

  const updateResumeMutation = useMutation({
    mutationFn: (data) => db.entities.Resume.update(resumeId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['resume', resumeId] });
      toast.success('Resume saved');
    }
  });

  const handleSave = () => {
    updateResumeMutation.mutate(resumeData);
  };

  const handlePersonalChange = (field, value) => {
    setResumeData(prev => ({
      ...prev,
      personal_details: {
        ...prev.personal_details,
        [field]: value
      }
    }));
  };

  const handleAddExperience = () => {
    setResumeData(prev => ({
      ...prev,
      experience: [
        ...(prev.experience || []),
        {
          job_title: '',
          company: '',
          location: '',
          start_date: '',
          end_date: '',
          current: false,
          description: '',
          achievements: []
        }
      ]
    }));
  };

  const handleExperienceChange = (index, field, value) => {
    setResumeData(prev => {
      const newExperience = [...(prev.experience || [])];
      newExperience[index] = {
        ...newExperience[index],
        [field]: value
      };
      return { ...prev, experience: newExperience };
    });
  };

  const handleRemoveExperience = (index) => {
    setResumeData(prev => ({
      ...prev,
      experience: prev.experience.filter((_, i) => i !== index)
    }));
  };

  const handleAddEducation = () => {
    setResumeData(prev => ({
      ...prev,
      education: [
        ...(prev.education || []),
        {
          degree: '',
          institution: '',
          location: '',
          start_date: '',
          end_date: '',
          gpa: ''
        }
      ]
    }));
  };

  const handleEducationChange = (index, field, value) => {
    setResumeData(prev => {
      const newEducation = [...(prev.education || [])];
      newEducation[index] = {
        ...newEducation[index],
        [field]: value
      };
      return { ...prev, education: newEducation };
    });
  };

  const handleAddSkill = () => {
    setResumeData(prev => ({
      ...prev,
      skills: [
        ...(prev.skills || []),
        { name: '', level: 'intermediate' }
      ]
    }));
  };

  const handleSkillChange = (index, field, value) => {
    setResumeData(prev => {
      const newSkills = [...(prev.skills || [])];
      newSkills[index] = {
        ...newSkills[index],
        [field]: value
      };
      return { ...prev, skills: newSkills };
    });
  };

  const calculateResumeScore = async () => {
    setCalculatingScore(true);
    try {
      const response = await db.integrations.Core.InvokeLLM({
        prompt: `Analyze this resume and provide detailed feedback with a score.

Resume data:
${JSON.stringify(resumeData, null, 2)}

Evaluate based on:
1. Completeness of information (contact details, experience, education, skills)
2. Professional formatting and structure
3. Clear achievements with quantifiable metrics
4. Relevant skills for the role
5. Grammar, clarity, and professional language
6. Overall impact and marketability

Provide your response in JSON format:`,
        response_json_schema: {
          type: "object",
          properties: {
            score: {
              type: "number",
              description: "Overall score from 0-100"
            },
            strengths: {
              type: "array",
              items: { type: "string" },
              description: "What's working well in the resume"
            },
            improvements: {
              type: "array",
              items: { type: "string" },
              description: "Specific areas to improve"
            },
            summary: {
              type: "string",
              description: "Overall assessment summary"
            }
          }
        }
      });
      
      const score = response.score || 0;
      setResumeData(prev => ({ 
        ...prev, 
        score,
        score_feedback: {
          strengths: response.strengths || [],
          improvements: response.improvements || [],
          summary: response.summary || ''
        }
      }));
      
      await updateResumeMutation.mutateAsync({ 
        ...resumeData, 
        score,
        score_feedback: {
          strengths: response.strengths || [],
          improvements: response.improvements || [],
          summary: response.summary || ''
        }
      });

      // Show detailed feedback
      if (score < 100) {
        toast.success(`Score: ${score}%`, {
          description: `${response.improvements?.length || 0} areas for improvement identified`,
          duration: 5000
        });
      } else {
        toast.success(`Perfect score: ${score}%! Your resume looks excellent.`);
      }
    } catch (error) {
      toast.error('Failed to calculate score');
    } finally {
      setCalculatingScore(false);
    }
  };

  if (isLoading || !resumeData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Bar */}
      <div className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate(createPageUrl('Dashboard'))}
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <Input
                  value={resumeData.title || ''}
                  onChange={(e) => setResumeData(prev => ({ ...prev, title: e.target.value }))}
                  className="text-lg font-semibold border-0 p-0 h-auto focus-visible:ring-0"
                  placeholder="Untitled Resume"
                />
                <p className="text-sm text-gray-500">
                  Last saved: {new Date(resumeData.updated_date).toLocaleString()}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {resumeData.score && (
                <Button
                  variant="outline"
                  className="flex items-center gap-2 px-3 py-2 bg-green-50 border-green-200 hover:bg-green-100"
                  onClick={() => {
                    const feedback = resumeData.score_feedback;
                    if (feedback && feedback.improvements?.length > 0) {
                      toast.info(`Score: ${resumeData.score}%`, {
                        description: feedback.improvements.slice(0, 3).join(' • '),
                        duration: 10000
                      });
                    }
                  }}
                >
                  <TrendingUp className="w-4 h-4 text-green-600" />
                  <span className="text-sm font-semibold text-green-600">
                    {resumeData.score}% Score
                  </span>
                  {resumeData.score < 100 && (
                    <span className="text-xs text-green-700">(Click for tips)</span>
                  )}
                </Button>
              )}
              <Button
                variant="outline"
                onClick={async () => {
                  await calculateResumeScore();
                  setShowScoreFeedback(true);
                }}
                disabled={calculatingScore}
              >
                {calculatingScore ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <TrendingUp className="w-4 h-4 mr-2" />
                )}
                Calculate Score
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowTemplateSelector(true)}
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Change Template
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowPreview(!showPreview)}
              >
                <Eye className="w-4 h-4 mr-2" />
                {showPreview ? 'Hide' : 'Show'} Preview
              </Button>
              <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700">
                <Save className="w-4 h-4 mr-2" />
                Save
              </Button>
              <Button variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Download
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Editor */}
          <div className="space-y-6">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="personal">Personal</TabsTrigger>
                <TabsTrigger value="experience">Experience</TabsTrigger>
                <TabsTrigger value="education">Education</TabsTrigger>
                <TabsTrigger value="skills">Skills</TabsTrigger>
              </TabsList>

              {/* Personal Details */}
              <TabsContent value="personal" className="space-y-4">
                <Card className="p-6">
                      <div className="flex justify-between items-center mb-4">
                    <div className="flex items-center gap-2">
                      <h2 className="text-xl font-semibold">Personal Details</h2>
                      <div className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full font-medium flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        AI Available
                      </div>
                    </div>
                    <AIAssistButton
                      section="Professional Summary"
                      currentContent={resumeData.summary || ''}
                      context={JSON.stringify({ job_title: resumeData.personal_details?.job_title, experience: resumeData.experience?.map(e => e.job_title) })}
                      onApply={(text) => setResumeData(prev => ({ ...prev, summary: text }))}
                    />
                  </div>

                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Full Name</Label>
                        <Input
                          value={resumeData.personal_details?.full_name || ''}
                          onChange={(e) => handlePersonalChange('full_name', e.target.value)}
                          placeholder="John Doe"
                        />
                      </div>
                      <div>
                        <Label>Job Title</Label>
                        <Input
                          value={resumeData.personal_details?.job_title || ''}
                          onChange={(e) => handlePersonalChange('job_title', e.target.value)}
                          placeholder="Software Engineer"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Email</Label>
                        <Input
                          type="email"
                          value={resumeData.personal_details?.email || ''}
                          onChange={(e) => handlePersonalChange('email', e.target.value)}
                          placeholder="john@example.com"
                        />
                      </div>
                      <div>
                        <Label>Phone</Label>
                        <Input
                          value={resumeData.personal_details?.phone || ''}
                          onChange={(e) => handlePersonalChange('phone', e.target.value)}
                          placeholder="+1 234 567 8900"
                        />
                      </div>
                    </div>

                    <div>
                      <Label>Location</Label>
                      <Input
                        value={resumeData.personal_details?.location || ''}
                        onChange={(e) => handlePersonalChange('location', e.target.value)}
                        placeholder="New York, NY"
                      />
                    </div>

                    <div>
                      <Label>Photo (Optional)</Label>
                      <div className="space-y-3">
                        {resumeData.personal_details?.photo_url ? (
                          <div className="flex items-center gap-4">
                            <img 
                              src={resumeData.personal_details.photo_url}
                              alt="Profile"
                              className="w-20 h-20 rounded-full object-cover border-2 border-gray-200"
                            />
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handlePersonalChange('photo_url', '')}
                            >
                              Remove Photo
                            </Button>
                          </div>
                        ) : (
                          <div>
                            <input
                              type="file"
                              id="photo-upload"
                              accept="image/*"
                              className="hidden"
                              onChange={async (e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  try {
                                    toast.info('Uploading and optimizing photo...');
                                    const { file_url } = await db.integrations.Core.UploadFile({ file });
                                    handlePersonalChange('photo_url', file_url);
                                    toast.success('Photo uploaded successfully');
                                  } catch (error) {
                                    toast.error('Failed to upload photo');
                                  }
                                }
                              }}
                            />
                            <label htmlFor="photo-upload">
                              <Button
                                variant="outline"
                                size="sm"
                                className="cursor-pointer"
                                type="button"
                                onClick={() => document.getElementById('photo-upload').click()}
                              >
                                <Upload className="w-4 h-4 mr-2" />
                                Upload Photo
                              </Button>
                            </label>
                            <p className="text-xs text-gray-500 mt-2">
                              AI will automatically resize and optimize your photo
                            </p>
                          </div>
                        )}
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <Label>Professional Summary</Label>
                        <AIAssistButton
                          section="Professional Summary"
                          currentContent={resumeData.summary || ''}
                          context={JSON.stringify({ job_title: resumeData.personal_details?.job_title, experience: resumeData.experience?.map(e => e.job_title) })}
                          onApply={(text) => setResumeData(prev => ({ ...prev, summary: text }))}
                        />
                      </div>
                      <Textarea
                        value={resumeData.summary || ''}
                        onChange={(e) => setResumeData(prev => ({ ...prev, summary: e.target.value }))}
                        placeholder="Write a brief professional summary..."
                        rows={5}
                      />
                    </div>
                  </div>
                </Card>
              </TabsContent>

              {/* Experience */}
              <TabsContent value="experience" className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-semibold">Work Experience</h2>
                    <div className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full font-medium flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      AI Writer Available
                    </div>
                  </div>
                  <Button onClick={handleAddExperience} size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Experience
                  </Button>
                </div>

                {(resumeData.experience || []).map((exp, index) => (
                  <Card key={index} className="p-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-semibold">Experience #{index + 1}</h3>
                      <div className="flex gap-2">
                        <AIAssistButton
                          section={`Experience — ${exp.job_title || 'Role'}`}
                          currentContent={exp.description || ''}
                          context={JSON.stringify({ ...exp, full_name: resumeData.personal_details?.full_name })}
                          onApply={(text) => handleExperienceChange(index, 'description', text)}
                        />
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleRemoveExperience(index)}
                        >
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Job Title</Label>
                          <Input
                            value={exp.job_title || ''}
                            onChange={(e) => handleExperienceChange(index, 'job_title', e.target.value)}
                            placeholder="Senior Developer"
                          />
                        </div>
                        <div>
                          <Label>Company</Label>
                          <Input
                            value={exp.company || ''}
                            onChange={(e) => handleExperienceChange(index, 'company', e.target.value)}
                            placeholder="Tech Corp"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <Label>Start Date</Label>
                          <Input
                            type="month"
                            value={exp.start_date || ''}
                            onChange={(e) => handleExperienceChange(index, 'start_date', e.target.value)}
                          />
                        </div>
                        <div>
                          <Label>End Date</Label>
                          <Input
                            type="month"
                            value={exp.end_date || ''}
                            onChange={(e) => handleExperienceChange(index, 'end_date', e.target.value)}
                            disabled={exp.current}
                          />
                        </div>
                        <div className="flex items-end">
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={exp.current || false}
                              onChange={(e) => handleExperienceChange(index, 'current', e.target.checked)}
                              className="rounded"
                            />
                            <span className="text-sm">Current</span>
                          </label>
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <Label>Description & Achievements</Label>
                          <AIAssistButton
                            section={`Experience — ${exp.job_title || 'Role'}`}
                            currentContent={exp.description || ''}
                            context={JSON.stringify({ ...exp, full_name: resumeData.personal_details?.full_name })}
                            onApply={(text) => handleExperienceChange(index, 'description', text)}
                          />
                        </div>
                        <Textarea
                          value={exp.description || ''}
                          onChange={(e) => handleExperienceChange(index, 'description', e.target.value)}
                          placeholder="Describe your role and achievements..."
                          rows={4}
                        />
                      </div>
                    </div>
                  </Card>
                ))}

                {(!resumeData.experience || resumeData.experience.length === 0) && (
                  <Card className="p-12 text-center">
                    <p className="text-gray-600 mb-4">No experience added yet</p>
                    <Button onClick={handleAddExperience}>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Your First Experience
                    </Button>
                  </Card>
                )}
              </TabsContent>

              {/* Education */}
              <TabsContent value="education" className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-semibold">Education</h2>
                  <Button onClick={handleAddEducation} size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Education
                  </Button>
                </div>

                {(resumeData.education || []).map((edu, index) => (
                  <Card key={index} className="p-6">
                    <div className="space-y-4">
                      <div className="flex justify-end">
                        <AIAssistButton
                          section={`Education — ${edu.degree || 'Degree'}`}
                          currentContent={edu.description || ''}
                          context={JSON.stringify({ degree: edu.degree, institution: edu.institution, job_title: resumeData.personal_details?.job_title })}
                          onApply={(text) => handleEducationChange(index, 'description', text)}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Degree</Label>
                          <Input
                            value={edu.degree || ''}
                            onChange={(e) => handleEducationChange(index, 'degree', e.target.value)}
                            placeholder="Bachelor of Science"
                          />
                        </div>
                        <div>
                          <Label>Institution</Label>
                          <Input
                            value={edu.institution || ''}
                            onChange={(e) => handleEducationChange(index, 'institution', e.target.value)}
                            placeholder="University Name"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <Label>Start Date</Label>
                          <Input
                            type="month"
                            value={edu.start_date || ''}
                            onChange={(e) => handleEducationChange(index, 'start_date', e.target.value)}
                          />
                        </div>
                        <div>
                          <Label>End Date</Label>
                          <Input
                            type="month"
                            value={edu.end_date || ''}
                            onChange={(e) => handleEducationChange(index, 'end_date', e.target.value)}
                          />
                        </div>
                        <div>
                          <Label>GPA (Optional)</Label>
                          <Input
                            value={edu.gpa || ''}
                            onChange={(e) => handleEducationChange(index, 'gpa', e.target.value)}
                            placeholder="3.8"
                          />
                        </div>
                      </div>

                      {edu.description && (
                        <div>
                          <Label>Description / Highlights</Label>
                          <Textarea
                            value={edu.description || ''}
                            onChange={(e) => handleEducationChange(index, 'description', e.target.value)}
                            placeholder="Relevant coursework, honors, activities..."
                            rows={3}
                          />
                        </div>
                      )}
                    </div>
                  </Card>
                ))}
              </TabsContent>

              {/* Skills */}
              <TabsContent value="skills" className="space-y-4">
                <div className="flex justify-between items-center flex-wrap gap-3">
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-semibold">Skills</h2>
                    <div className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full font-medium flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      AI Available
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <AISkillsSuggestButton
                      context={JSON.stringify({ job_title: resumeData.personal_details?.job_title, experience: resumeData.experience?.map(e => `${e.job_title} at ${e.company}`), education: resumeData.education?.map(ed => ed.degree) })}
                      existingSkills={resumeData.skills || []}
                      onAddSkills={(skills) => {
                        const newSkills = skills.map(name => ({ name, level: 'intermediate' }));
                        setResumeData(prev => ({ ...prev, skills: [...(prev.skills || []), ...newSkills] }));
                      }}
                    />
                    <Button onClick={handleAddSkill} size="sm">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Skill
                    </Button>
                  </div>
                </div>

                <Card className="p-6">
                  <div className="space-y-3">
                    {(resumeData.skills || []).map((skill, index) => (
                      <div key={index} className="flex gap-3">
                        <Input
                          value={skill.name || ''}
                          onChange={(e) => handleSkillChange(index, 'name', e.target.value)}
                          placeholder="Skill name"
                          className="flex-1"
                        />
                        <Select
                          value={skill.level || 'intermediate'}
                          onValueChange={(value) => handleSkillChange(index, 'level', value)}
                        >
                          <SelectTrigger className="w-40">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="beginner">Beginner</SelectItem>
                            <SelectItem value="intermediate">Intermediate</SelectItem>
                            <SelectItem value="advanced">Advanced</SelectItem>
                            <SelectItem value="expert">Expert</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    ))}
                  </div>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Preview */}
          {showPreview && (
            <div className="lg:sticky lg:top-24 h-fit">
              <Card className="p-6 bg-gray-100 overflow-auto" style={{ maxHeight: 'calc(100vh - 120px)' }}>
                <div className="scale-50 origin-top-left" style={{ width: '200%' }}>
                  <ResumePreview resume={resumeData} template={resumeData.template} />
                </div>
              </Card>
            </div>
          )}
        </div>
      </div>

      <TemplateSelector
        open={showTemplateSelector}
        onClose={() => setShowTemplateSelector(false)}
        currentTemplate={resumeData?.template}
        onSelectTemplate={(templateId) => {
          setResumeData(prev => ({ ...prev, template: templateId }));
          toast.success('Template changed');
        }}
      />

      <ScoreFeedbackDialog
        open={showScoreFeedback}
        onClose={() => setShowScoreFeedback(false)}
        score={resumeData?.score}
        feedback={resumeData?.score_feedback}
      />
    </div>
  );
}