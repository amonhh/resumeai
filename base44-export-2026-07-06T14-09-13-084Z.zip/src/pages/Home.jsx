import React from 'react';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Sparkles, FileText, Zap, Target, Download, Shield } from "lucide-react";
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Home() {
  const navigate = useNavigate();

  const features = [
    {
      icon: Sparkles,
      title: 'AI-Powered Writing',
      description: 'Let AI craft compelling content for every section of your resume'
    },
    {
      icon: Target,
      title: 'ATS Optimization',
      description: 'Templates designed to pass applicant tracking systems'
    },
    {
      icon: Zap,
      title: 'Fast & Easy',
      description: 'Create a professional resume in minutes, not hours'
    },
    {
      icon: Download,
      title: 'Multiple Formats',
      description: 'Download as PDF, DOCX, or TXT format'
    },
    {
      icon: Shield,
      title: 'Resume Score',
      description: 'Get instant feedback with AI-powered resume scoring'
    },
    {
      icon: FileText,
      title: 'Professional Templates',
      description: 'Choose from expertly designed resume templates'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-6 py-20">
        <div className="text-center max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm font-medium mb-8">
            <Sparkles className="w-4 h-4" />
            AI-Powered Resume Builder
          </div>
          
          <h1 className="text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Create Your Perfect Resume with AI
          </h1>
          
          <p className="text-xl text-gray-600 mb-10 leading-relaxed">
            Build a professional resume in minutes with AI assistance. 
            Choose from expertly designed templates, get AI-powered writing help, 
            and land your dream job faster.
          </p>

          <div className="flex gap-4 justify-center">
            <Button 
              onClick={() => navigate(createPageUrl('Dashboard'))}
              size="lg"
              className="bg-blue-600 hover:bg-blue-700 text-lg h-14 px-8"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Create My Resume
            </Button>
            <Button 
              onClick={() => navigate(createPageUrl('Templates'))}
              size="lg"
              variant="outline"
              className="text-lg h-14 px-8"
            >
              <FileText className="w-5 h-5 mr-2" />
              Browse Templates
            </Button>
          </div>
        </div>

        {/* Preview Image */}
        <div className="mt-20 relative">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 blur-3xl" />
          <Card className="relative overflow-hidden shadow-2xl">
            <img 
              src="https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=1200&h=600&fit=crop" 
              alt="Resume Builder Preview"
              className="w-full h-auto"
            />
          </Card>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Everything You Need to Get Hired
            </h2>
            <p className="text-xl text-gray-600">
              Powerful features to help you create the perfect resume
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <Card key={idx} className="p-6 hover:shadow-xl transition-shadow">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600">
                    {feature.description}
                  </p>
                </Card>
              );
            })}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="max-w-7xl mx-auto px-6 py-20">
        <Card className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-16 text-center">
          <h2 className="text-4xl font-bold mb-4">
            Ready to Build Your Resume?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join thousands of job seekers who have landed their dream jobs with our AI-powered resume builder
          </p>
          <Button 
            onClick={() => navigate(createPageUrl('Dashboard'))}
            size="lg"
            className="bg-white text-blue-600 hover:bg-gray-100 text-lg h-14 px-8"
          >
            Get Started for Free
          </Button>
        </Card>
      </div>
    </div>
  );
}